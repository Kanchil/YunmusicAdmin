<?php
return array(	
	'app_init'=>array('Common\\Behavior\\InitHookBehavior'),
	'view_filter' => array('Common\\Behavior\\FilterTmplBehavior'),
);