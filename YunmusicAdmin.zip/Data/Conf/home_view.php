<?php	return array (
  'URL_MODEL' => '3',
  'HTML_CACHE_ON' => '0',
  'HTML_CACHE_TIME' => '86400',
  'HTML_FILE_SUFFIX' => '.html',
  'DEFAULT_THEME' => 'default/Home',
  'TMPL_PARSE_STRING' => 
  array (
    '__STATIC__' => '/Public/static',
    '__TMPL__' => '/Template/default/static',
  ),
);