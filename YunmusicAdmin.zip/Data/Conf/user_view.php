<?php	return array (
  'URL_MODEL' => '3',
  'DEFAULT_THEME' => 'default/User',
  'TMPL_PARSE_STRING' => 
  array (
    '__STATIC__' => '/Public/static',
    '__TMPL__' => '/Template/default/static',
  ),
);