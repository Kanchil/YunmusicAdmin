<?php
// +-------------------------------------------------------------+
// | Author: 战神~~巴蒂 <378020023@qq.com> <http://www.jyuu.cn>  |
// +-------------------------------------------------------------+

/**
 * 系统配文件
 * 所有系统级别的配置
 */;
// if (!defined('JYMUSIC_VERSION')) exit();
define('UC_AUTH_KEY', 'n~sm]Ur/e"Ad|TuJG9;CiMSB)o_7PHOK8IyW6}h,'); //加密KE
define('DB_TYPE','mysql'); // 数据库类型
define('DB_HOST', '127.0.0.1');  // 服务器地址
define('DB_NAME','YunMusic');  // 数据库名
define('DB_USER', 'root');  // 用户名
define('DB_PWD' ,'root');  // 密码
define('DB_PORT' ,'3306') ; // 端口
define('DB_PREFIX','ym_'); // 数据库表前缀
